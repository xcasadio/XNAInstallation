' TODO: replace this with the type you want to write out.
Imports TWrite = System.String
Imports Microsoft.Xna.Framework.Content.Pipeline.Serialization.Compiler

''' <summary>
''' This class will be instantiated by the XNA Framework Content Pipeline
''' to write the specified data type into binary .xnb format.
'''
''' This should be part of a Content Pipeline Extension Library project.
''' </summary>
<ContentTypeWriter>
Public Class $safeitemname$
    Inherits ContentTypeWriter(Of TWrite)

    Protected Overrides Sub Write(ByVal output As ContentWriter, ByVal value As TWrite)
        ' TODO: write the specified value to the output ContentWriter.
        Throw New NotImplementedException
    End Sub

    Public Overrides Function GetRuntimeReader(ByVal targetPlatform As Pipeline.TargetPlatform) As String
        ' TODO: change this to the name of your ContentTypeReader
        ' class which will be used to load this data.
        Return "MyNamespace.MyContentReader, MyGameAssembly"
    End Function

End Class

' TODO: replace these with the processor input and output types.
Imports TInput = System.String
Imports TOutput = System.String

''' <summary>
''' This class will be instantiated by the XNA Framework Content Pipeline
''' to apply custom processing to content data, converting an object of
''' type TInput to TOutput. The input and output types may be the same if
''' the processor wishes to alter data without changing its type.
'''
''' This should be part of a Content Pipeline Extension Library project.
'''
''' TODO: change the ContentProcessor attribute to specify the correct
''' display name for this processor.
''' </summary>
<Pipeline.ContentProcessorAttribute(DisplayName := "$rootnamespace$.$safeitemname$")>
Public Class $safeitemname$
    Inherits Pipeline.ContentProcessor(Of TInput, TOutput)

    Public Overrides Function Process(ByVal input As TInput, ByVal context As Pipeline.ContentProcessorContext) As TInput
        ' TODO: process the input object, and return the modified data.
        Throw New NotImplementedException
    End Function

End Class

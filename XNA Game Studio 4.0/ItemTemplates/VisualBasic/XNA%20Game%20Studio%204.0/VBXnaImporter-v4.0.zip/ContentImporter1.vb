' TODO: replace this with the type you want to import.
Imports TImport = System.String

''' <summary>
''' This class will be instantiated by the XNA Framework Content Pipeline
''' to import a file from disk into the specified type, TImport.
''' 
''' This should be part of a Content Pipeline Extension Library project.
''' 
''' TODO: change the ContentImporter attribute to specify the correct file
''' extension, display name, and default processor for this importer.
''' </summary>
<Pipeline.ContentImporterAttribute(".abc", DisplayName:="ABC Importer", DefaultProcessor:="AbcProcessor")>
Public Class $safeitemname$
    Inherits Pipeline.ContentImporter(Of TImport)

    Public Overrides Function Import(ByVal filename As String, ByVal context As Pipeline.ContentImporterContext) As TImport
        ' TODO: read the specified file into an instance of the imported type.
        Throw New NotImplementedException
    End Function
End Class

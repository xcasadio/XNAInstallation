''' <summary>
''' This is a game component that implements IUpdateable.
''' </summary>
Public Class $safeitemname$
    Inherits Microsoft.Xna.Framework.GameComponent

    Public Sub New(ByVal game As Game)
        MyBase.New(game)
        ' TODO: Construct any child components here
    End Sub

    ''' <summary>
    ''' Allows the game component to perform any initialization it needs to before starting
    ''' to run.  This is where it can query for any required services and load content.
    ''' </summary>
    Public Overrides Sub Initialize()
        ' TODO: Add your initialization code here
        MyBase.Initialize()
    End Sub

    ''' <summary>
    ''' Allows the game component to update itself.
    ''' </summary>
    ''' <param name="gameTime">Provides a snapshot of timing values.</param>
    Public Overrides Sub Update(ByVal gameTime As GameTime)
        ' TODO: Add your update code here
        MyBase.Update(gameTime)
    End Sub

End Class

﻿Public Interface $safeitemname$

End Interface
